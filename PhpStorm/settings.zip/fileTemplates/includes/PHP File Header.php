/**
 *
 *
 * Created by ${PRODUCT_NAME}
 * User: Alex
 * Date: ${YEAR}-${MONTH}-${DAY} ${TIME}
 */
 declare(strict_types=1);